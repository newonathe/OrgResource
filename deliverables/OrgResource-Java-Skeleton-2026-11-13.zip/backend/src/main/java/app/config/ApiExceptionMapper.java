package app.config;

import javax.validation.ConstraintViolationException;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import app.components.ApiException;
import app.dto.ApiDtos.ErrorView;

@Provider
public class ApiExceptionMapper implements ExceptionMapper<Exception> {
    private static final Logger LOG = LoggerFactory.getLogger(ApiExceptionMapper.class);

    @Override
    public Response toResponse(Exception error) {
        if (error instanceof ApiException) {
            ApiException api = (ApiException) error;
            return Response.status(api.status).type(MediaType.APPLICATION_JSON_TYPE)
                    .entity(new ErrorView(api.code, api.getMessage())).build();
        }
        if (error instanceof ConstraintViolationException || error instanceof BadRequestException) {
            return Response.status(Response.Status.BAD_REQUEST).type(MediaType.APPLICATION_JSON_TYPE)
                    .entity(new ErrorView("VALIDATION_FAILED", "The request is invalid.")).build();
        }
        LOG.error("Unhandled request error", error);
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(MediaType.APPLICATION_JSON_TYPE)
                .entity(new ErrorView("INTERNAL_ERROR", "An unexpected server error occurred.")).build();
    }
}
